package se.mah.KD405A.khallberg_4A;

public class Dog {
	
	private String name;
	
	public Dog(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
}
